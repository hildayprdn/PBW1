package id.ilham.project_baru

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
